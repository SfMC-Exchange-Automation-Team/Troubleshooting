TLC Toolbox 0.1.59
Teams Log Collection Toolbox

WHAT THIS IS
    Collects Microsoft Teams logs for a specific window of time, following the
    published Log Collection Guidelines. Teams keeps its logs on disk, so an issue
    that has already cleared can still be collected after the fact.

BEFORE YOU EXTRACT  -  please do this first
    Right-click this .zip, choose Properties, tick Unblock, then OK.

    Windows marks anything that arrives by email, Teams or download. Unblocking
    the .zip once clears every file inside it. Without it Windows blocks the
    scripts, because this build is not code signed.
    The EXE is also unsigned: SmartScreen or corporate application control may
    refuse it. Use an IT-approved route; do not bypass organizational policy.

TO RUN
    Extract the whole folder and keep it together, then double-click:

        TLC-Toolbox.exe          the icon-bearing application - start here
        Start-TlcToolbox.cmd     script-based fallback
        Collect-TeamsLogs.cmd    collect straight away, no window

    The EXE installs a clean per-user copy under %LOCALAPPDATA%\Programs\TLC-Toolbox
    and adds TLC Toolbox to the Start menu. No administrator rights are needed.
    Right-click that Start menu entry to Pin to Start or Pin to taskbar.
    The running toolbox taskbar button can also be pinned. Pins reopen the EXE,
    not a generic PowerShell console. Moving/deleting the extracted download
    afterwards does not remove the installed application or its icon.

REQUIREMENTS
    Windows PowerShell 5.1, included with Windows 10 and 11. No extra modules
    or administrator rights are needed. Installation writes to your per-user
    Programs folder; settings and evidence are stored separately.
    The extracted source can be on a read-only share; installation still needs
    write access to your own per-user Programs folder.

WHERE THINGS GO
    Collected evidence   %SystemDrive%\TLC-Toolbox\Runs   (the window can change this)
    Your own settings    %LOCALAPPDATA%\TLC-Toolbox

    Remembered case numbers are stored per user under %LOCALAPPDATA%. The wizard's
    Forget button clears them. Accounts you declare from the Signed in tile are saved
    there too, in TeamsLogCollection.local.psd1 - never in this folder.

BEFORE SHARING WHAT IT COLLECTS
    Use Package in the window. It runs a privacy check over the evidence and seals
    the bundle with a hash, so both sides can prove later what was handed over.
