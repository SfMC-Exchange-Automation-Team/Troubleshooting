TLC Toolbox 0.1.58
Teams Log Collection Toolbox

WHAT THIS IS
    Collects Microsoft Teams logs for a specific window of time, following the
    published Log Collection Guidelines. Teams keeps its logs on disk, so an issue
    that has already cleared can still be collected after the fact.

BEFORE YOU EXTRACT  -  please do this first
    Right-click this .zip, choose Properties, tick Unblock, then OK.

    Windows marks anything that arrives by email, Teams or download. Unblocking
    the .zip once clears every file inside it. Without it Windows blocks the
    scripts, because this build is not code signed.

TO RUN
    Extract the whole folder and keep it together, then double-click:

        Start-TlcToolbox.cmd     the guided window - start here
        Collect-TeamsLogs.cmd    collect straight away, no window

    To open it from the Start menu next time, with its own icon: Settings (the gear,
    bottom left), then Add to Start menu. The entry opens the folder it was added
    from, so add it once the toolbox is extracted where it will stay. It can be
    pinned to the taskbar from the Start menu.

REQUIREMENTS
    Windows PowerShell 5.1, included with Windows 10 and 11. Nothing to install,
    no admin rights needed, and nothing is written into this folder - so it can be
    run from a read-only share.

WHERE THINGS GO
    Collected evidence   %SystemDrive%\TLC-Toolbox\Runs   (the window can change this)
    Your own settings    %LOCALAPPDATA%\TLC-Toolbox

    Remembered case numbers are stored per user under %LOCALAPPDATA%. The wizard's
    Forget button clears them. Accounts you declare from the Signed in tile are saved
    there too, in TeamsLogCollection.local.psd1 - never in this folder.

BEFORE SHARING WHAT IT COLLECTS
    Use Package in the window. It runs a privacy check over the evidence and seals
    the bundle with a hash, so both sides can prove later what was handed over.
